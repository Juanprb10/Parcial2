package com.example.myapplication

import android.R
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale


class FacturaActivity : AppCompatActivity() {
    private var cantidadEditText: EditText? = null
    private var precioEditText: EditText? = null
    private var totalTextView: TextView? = null
    private var calcularButton: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.list_content)
        cantidadEditText = findViewById<EditText>(R.id.cantidadEditText)
        precioEditText = findViewById<EditText>(R.id.precioEditText)
        totalTextView = findViewById<TextView>(R.id.totalTextView)
        calcularButton = findViewById<Button>(R.id.calcularButton)
        calcularButton.setOnClickListener(View.OnClickListener { calcularTotal() })
    }

    private fun calcularTotal() {
        // Obtener cantidad y precio
        val cantidad = cantidadEditText!!.text.toString().toInt()
        val precio = precioEditText!!.text.toString().toDouble()

        // Calcular total
        val total = cantidad * precio

        // Mostrar total en el TextView
        totalTextView!!.text =
            String.format(Locale.getDefault(), "Total: %.2f", total)
    }
}

